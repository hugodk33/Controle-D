import React from 'react';

//{props.soma? <span className="soma-span">+</span> : null}

const SomatoriaAlimentos = (props) => {

    return (
        <div className={"ItemSomatoriaAlimento"}>
            <div className={"valores"}>
                <p>{props.valor}</p>
                <hr />
                <p className="subtitle">{props.subtitulo}</p>
            </div>        
            {props.soma? <span className="soma-span">+</span> : null}
        </div>
    )
};

export default SomatoriaAlimentos;

