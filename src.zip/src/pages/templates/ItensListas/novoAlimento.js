import React from 'react';
import SubRowItem from "./SubRowItem";
import TituloForm from "../../templates/TituloForm";
import InputSelect from "../Inputs/InputSelect";
import InputN from "../Inputs/InputN";
import { IconeAdicionarRefeicao } from '../icons/icones-botoes'

const ItemAlimento = (props) => {
    return (
        <div className="row" style={{marginTop: "25px"}}>
            <TituloForm />
            <div className="col-4 col-sm-4">
                <InputSelect label="ALIMENTO"/>
            </div>
            <div className="col-4 col-sm-4">
                <InputN label="QUANT." />
            </div> 
            <div className="col-4 col-sm-4">
                <InputSelect label="PORÇÃO" />
            </div>            
            <div className="col-5 separador">
                <hr style={{border:"3px solid #f4f4f4"}}/>
            </div>
            <div className="col-2" style={{textAlign: "center"}}>
                <button className="btn btn-primary btn-soma" style={{padding: "2px 9px"}}><IconeAdicionarRefeicao /></button>
            </div>
            <div className="col-5 separador">
                <hr style={{border:"3px solid #f4f4f4"}}/>
            </div>   
        </div>
    )
};

export default ItemAlimento;
