import React from 'react';
import {IconeFormAlimento, IconeFormAtributo , IconeFormMedico } from './icons/icones-formulario'

const TituloForm = (props) => {

  return (
    <div className={"col-12 text-left"}><div style={{backgroundColor:"#f4f4f4", width: "100%", padding: "0 10px", marginBottom: "12px"}}><h5 className="titulo-3"><IconeFormMedico /> CONDIÇÃO </h5></div></div>
  );
};

export default TituloForm;
