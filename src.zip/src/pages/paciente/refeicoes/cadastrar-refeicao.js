import React from 'react';
import { connect, createSelectorHook, useSelector } from 'react-redux'
import { compose , bindActionCreators } from 'redux'
import Titulo from "../../templates/Titulo";
import TituloForm from "../../templates/TituloForm";
import Menu from "../../templates/MenuPaciente";
import Input from "../../templates/Inputs/Input";
import InputN from "../../templates/Inputs/InputN";
import InputSelect from "../../templates/Inputs/InputSelect";
import PaginacaoBtn from '../../templates/ItensListas/paginacao/marcadores-de-paginacao';
import ItemAlimentoDiario from "../../templates/ItensListas/itemAlimentoDiario";
import SomatoriaAlimentos from "../../templates/SomatoriaAlimentos";
import ItemRefeicao from "../../templates/ItensListas/ItemRefeicao";
import NovoAlimento from "../../templates/ItensListas/novoAlimento";
import SubRowItem from "../../templates/ItensListas/SubRowItem";
import { withRouter } from 'react-router-dom';
import { Select } from '@material-ui/core';

import alimentosRefeicao from '../../jsons/alimentos-pacientes.json'

import {IconeFormAlimento, IconeFormAtributo , IconeFormMedico } from '../../templates/icons/icones-formulario'
import { IconeTituloAdicionarRefeicao } from '../../templates/icons/icones-navegacao'


const CadastrarRefeicao = (props, state) => {

  //const alimentosRefeicao = useSelector(state => state.AlimentosPacientes)
  //<NovoAlimento />
  //<InputSelect id="organizar-alimento" label="ORGANIZAR POR: " col="6 col-sm-4"/>

  return (
    <div>
      <div className="row main" style={{margin:"0"}}>
        <div className="col-12 col-sm-3 menu-lateral">
          <Menu />
        </div>
        <div className="col-12 col-md-6 canvas-board"> 
          <div className="container">
            <div class="row">
              <div class="col-12 text-center">
                <IconeTituloAdicionarRefeicao />
                <Titulo titulo={"Cadastrar Refeição"}/>
              </div>
              <div className="col-12" style={{padding: "0"}}>
                <Select />
                <div className="row">
                  <TituloForm />
                  <Input label="NOME DA REFEIÇÃO" col="12"/>
                  <Input label="HORA" col="4"/>
                  <Input label="DATA" col="4"/>
                  <InputSelect label="ÍCONE" col="4"/>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12 dinamic">
              <div className={"col-12 text-left"}><div style={{ width: "100%", display: "inline-block", padding: "0px 10px"}}><h5 className="titulo-3"><IconeFormMedico /> CONDIÇÃO </h5></div></div>
                <div class="moldura">
                  <div class="SomatoriaRefeicao">
                    <SomatoriaAlimentos col="3 ponta-esq" subtitulo={'Alimento 1'} valor={'10'} soma={true}/>
                    <SomatoriaAlimentos col="3" subtitulo={'Alimento 2'} valor={'13'} soma={true}/>
                    <SomatoriaAlimentos col="3" subtitulo={'Alimento 3'} valor={'11'} soma={true}/>
                    <SomatoriaAlimentos col="3 ponta-dir" subtitulo={'Alimento 4'} valor={'12'} soma={false}/>
                  </div>
                  <div class="doses-de-insulina-output">
                    <span>10</span>
                    <p class="subtitle">DOSES</p>
                  </div>
                </div>
              </div>
            </div>
            <NovoAlimento />
            <div class="row">
              <div class="col-md-12">
                <ul className="lista">
                  { 
                    alimentosRefeicao.map((a , b) => {
                      return <ItemAlimentoDiario key={b} data={a}/>
                    })
                  }
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default withRouter(CadastrarRefeicao);
