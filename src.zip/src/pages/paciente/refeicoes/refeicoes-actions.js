// import alimentoAPI from "../../../apis/controleDAPi"
// import {createAction } from '@reduxjs/toolkit'
// import { setAlimentos } from "../../medico/alimentos/alimentos-reducers"

// export const createAlimento = createAction('createAlimento', alimento => {

// })

// export const getAllAlimentos = createAction('getAllAlimentos', async (descricao) => {

//     try {

//         const alimentos = await alimentoAPI.get('alimento', {
//             params: {
//                 descricao
//             }
//         })

//         setAlimentos(alimentos)
//     }catch(e){
//         console.error(e)
//     }
// })