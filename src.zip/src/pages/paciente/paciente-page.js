import React from 'react';
import { withRouter } from 'react-router-dom';

const Paciente = (props) => {

  return (
    <div>
    </div>
  );
};

export default withRouter(Paciente);
