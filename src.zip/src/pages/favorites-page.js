import React, { useEffect } from 'react';

export const Favorites = () => {
  
  return (
    <div>
      
    </div>
  );
};
